KKM99 Android App - ফোন থেকে APK তৈরি করার ফাইল

অ্যাপের ঠিকানা: https://kkm99.com
অ্যাপের নাম: KKM99
আইকন: দেওয়া KKM99 লোগো

APK তৈরির সহজ পদ্ধতি (কম্পিউটার ছাড়াই):
1. ফোনের Chrome-এ https://github.com খুলে একটি ফ্রি অ্যাকাউন্ট খুলুন/লগইন করুন।
2. New repository তৈরি করুন। নাম দিন KKM99-Android-App। Public বা Private যেকোনোটি হতে পারে।
3. এই ZIP ফাইলটি Extract করুন। ভেতরের সব ফাইল-ফোল্ডার GitHub repository-তে আপলোড করুন। .github ফোল্ডারটিও অবশ্যই আপলোড করতে হবে।
4. GitHub repository-র Actions ট্যাবে যান। "Build KKM99 APK" workflow খুলে "Run workflow" চাপুন।
5. Build শেষ হলে workflow run-এর নিচের Artifacts থেকে KKM99-Android-APK ডাউনলোড করুন।
6. ZIP extract করে app-debug.apk ফোনে ইনস্টল করুন। Android-এ প্রয়োজন হলে এই ফাইল/Chrome-এর জন্য "Install unknown apps" অনুমতি দিন।

গুরুত্বপূর্ণ:
- এটি প্রথম পরীক্ষামূলক Debug APK; Play Store-এর জন্য signed release build নয়।
- APK ইনস্টল করতে Android ফোন লাগবে।
- ওয়েবসাইটের লগইন/অন্যান্য কাজ ওয়েবসাইটের সার্ভারের ওপর নির্ভর করবে।
- ওয়েবসাইটের বাইরে অন্য ডোমেইনের লিংক ফোনের browser-এ খুলবে।
- iOS-এর জন্য APK ব্যবহার করা যায় না; iOS app আলাদা ব্যবস্থা।
